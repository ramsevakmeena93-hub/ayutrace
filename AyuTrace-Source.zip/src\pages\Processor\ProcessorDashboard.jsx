import React, { useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Package, Clock, CheckCircle, Activity } from 'lucide-react'

const ProcessorDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview')

  const stats = [
    { label: 'Total Received', value: '156', icon: Package, color: '#ff9800' },
    { label: 'Under Processing', value: '42', icon: Clock, color: '#2196f3' },
    { label: 'Ready for Testing', value: '28', icon: CheckCircle, color: '#4caf50' },
    { label: 'Blockchain Synced', value: '86', icon: Activity, color: '#9c27b0' },
  ]

  const chartData = [
    { month: 'Jan', harvesting: 40, processing: 24 },
    { month: 'Feb', harvesting: 30, processing: 18 },
    { month: 'Mar', harvesting: 50, processing: 35 },
    { month: 'Apr', harvesting: 45, processing: 30 },
  ]

  const herbsInProcessing = [
    { id: 1, name: 'Ashwagandha', weight: '50kg', facility: 'Center A', status: 'Processing' },
    { id: 2, name: 'Tulsi', weight: '30kg', facility: 'Center B', status: 'Ready' },
  ]

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Processor Dashboard</h1>

      <div style={styles.statsGrid}>
        {stats.map((stat, idx) => (
          <div key={idx} style={styles.statCard}>
            <stat.icon size={32} color={stat.color} />
            <div>
              <p style={styles.statValue}>{stat.value}</p>
              <p style={styles.statLabel}>{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div style={styles.chartCard}>
        <h3 style={styles.chartTitle}>Harvesting & Processing Overview</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="harvesting" fill="#ff9800" />
            <Bar dataKey="processing" fill="#2196f3" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={styles.tabs}>
        <button
          style={{...styles.tab, ...(activeTab === 'overview' ? styles.activeTab : {})}}
          onClick={() => setActiveTab('overview')}
        >
          Herbs in Processing
        </button>
        <button
          style={{...styles.tab, ...(activeTab === 'form' ? styles.activeTab : {})}}
          onClick={() => setActiveTab('form')}
        >
          Processing Form
        </button>
      </div>

      {activeTab === 'overview' && (
        <div style={styles.content}>
          <div style={styles.table}>
            <div style={styles.tableHeader}>
              <div>Herb Name</div>
              <div>Weight</div>
              <div>Facility</div>
              <div>Status</div>
            </div>
            {herbsInProcessing.map((herb) => (
              <div key={herb.id} style={styles.tableRow}>
                <div>{herb.name}</div>
                <div>{herb.weight}</div>
                <div>{herb.facility}</div>
                <div>
                  <span style={{...styles.badge, background: herb.status === 'Ready' ? '#4caf50' : '#ff9800'}}>
                    {herb.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'form' && (
        <div style={styles.content}>
          <form style={styles.form}>
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Processing Type</label>
                <select style={styles.input}>
                  <option>Select type</option>
                  <option>Drying</option>
                  <option>Grinding</option>
                  <option>Extraction</option>
                </select>
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Net Weight (kg)</label>
                <input type="number" style={styles.input} placeholder="Enter weight" />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Facility Name</label>
                <input type="text" style={styles.input} placeholder="Enter facility name" />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Location</label>
                <input type="text" style={styles.input} placeholder="Enter location" />
              </div>
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Notes</label>
              <textarea style={{...styles.input, minHeight: '80px'}} placeholder="Additional notes"></textarea>
            </div>
            <button type="submit" style={styles.submitBtn}>Submit to Blockchain</button>
          </form>
        </div>
      )}
    </div>
  )
}

const styles = {
  container: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '2rem 1rem',
  },
  title: {
    fontSize: '2rem',
    color: '#e65100',
    marginBottom: '2rem',
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
    gap: '1.5rem',
    marginBottom: '2rem',
  },
  statCard: {
    background: 'white',
    padding: '1.5rem',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  statValue: {
    fontSize: '1.8rem',
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    color: '#666',
    fontSize: '0.9rem',
  },
  chartCard: {
    background: 'white',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
    marginBottom: '2rem',
  },
  chartTitle: {
    fontSize: '1.3rem',
    color: '#333',
    marginBottom: '1.5rem',
  },
  tabs: {
    display: 'flex',
    gap: '1rem',
    marginBottom: '2rem',
    borderBottom: '2px solid #e0e0e0',
  },
  tab: {
    padding: '0.8rem 1.5rem',
    background: 'transparent',
    border: 'none',
    fontSize: '1rem',
    fontWeight: '500',
    color: '#666',
    cursor: 'pointer',
    borderBottom: '3px solid transparent',
  },
  activeTab: {
    color: '#e65100',
    borderBottom: '3px solid #e65100',
  },
  content: {
    background: 'white',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
  },
  table: {
    width: '100%',
  },
  tableHeader: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr 1.5fr 1fr',
    padding: '1rem',
    background: '#f5f5f5',
    fontWeight: '600',
    borderRadius: '6px 6px 0 0',
  },
  tableRow: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr 1.5fr 1fr',
    padding: '1rem',
    borderBottom: '1px solid #e0e0e0',
    alignItems: 'center',
  },
  badge: {
    display: 'inline-block',
    padding: '0.3rem 0.8rem',
    borderRadius: '12px',
    color: 'white',
    fontSize: '0.85rem',
    fontWeight: '500',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
  },
  formGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1.5rem',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  label: {
    fontWeight: '500',
    color: '#333',
    fontSize: '0.95rem',
  },
  input: {
    padding: '0.7rem',
    border: '2px solid #e0e0e0',
    borderRadius: '6px',
    fontSize: '0.95rem',
  },
  submitBtn: {
    padding: '1rem',
    background: 'linear-gradient(135deg, #ff9800 0%, #f57c00 100%)',
    color: 'white',
    borderRadius: '6px',
    fontSize: '1.1rem',
    fontWeight: '600',
    cursor: 'pointer',
  },
}

export default ProcessorDashboard
